A gui framework a PySide 6 lesz.



py -m pip install PySide6