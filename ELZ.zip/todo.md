# További teendők a projekt beadásáig

## Korábbi munka javítása és ellenőrzése
- Monitoring funkció létrehozása - **KÉSZ**.
- Kihasználtság: fájlba írás pótlása;
- Számítógép törlése: hiányos implementálás *(nem találtam meg, hogy mi a gond)* - **KÉSZ**.
- Program leállítása: csak részlegesen van kész - **KÉSZ**.

## Újonnan létrehozott funkciók
- Grafikus környezet készítése
    - Saját logó *(ChatGPT 0. verzió feltöltve)* - **KÉSZ**.

git test 1