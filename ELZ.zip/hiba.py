def hiba(ok: str):
    print(f"ERROR: {ok}")


def warning(msg):
    print(f"WARNING: {msg}")