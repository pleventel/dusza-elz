ELZ csapat - dokumentáció

A program elindítása a 'menu.py' fájl futtatásával lehetséges, bármilyen Python 3.9-es (vagy újabb) környezetben.
A program elindítása után a konzolon keresztül lehetséges a kommunikáció. 